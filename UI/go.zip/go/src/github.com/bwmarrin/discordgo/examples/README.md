<img align="right" src="http://bwmarrin.github.io/discordgo/img/discordgo.png">

# DiscordGo Examples

These examples demonstrate how to utilize DiscordGo.

Please explore the individual folders and give them a try!

**Join [Discord Gophers](https://discord.gg/0f1SbxBZjYoCtNPP)
Discord chat channel for support.**

