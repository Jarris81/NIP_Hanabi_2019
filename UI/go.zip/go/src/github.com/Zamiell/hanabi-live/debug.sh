#!/bin/bash

# Debug is mapped to SIGUSR2
pkill -SIGUSR2 hanabi-live
