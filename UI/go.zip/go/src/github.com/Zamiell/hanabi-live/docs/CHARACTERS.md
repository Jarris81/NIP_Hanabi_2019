# Detrimental Character Assignments

* On Hanabi Live, "Detrimental Character Assignments" can be enabled for a game, which restrict players in additional ways beyond the normal rules.
* These characters are loosly based on [this post](https://boardgamegeek.com/thread/1688194/hanabi-characters-variant) from Sean McCarthy on the Board Game Geek forums.

<br />

## List of Characters

As the list of characters are in flux, please look at the [constants.js file](https://github.com/Zamiell/hanabi-live/blob/master/public/js/src/constants.js) for the full listing. (Ctrl + F for "Characters".)
