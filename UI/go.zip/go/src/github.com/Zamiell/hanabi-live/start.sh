#!/bin/bash

supervisorctl start hanabi-live
