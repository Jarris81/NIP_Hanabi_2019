class Clue {
    constructor(type, value) {
        this.type = type;
        this.value = value;
    }
}

module.exports = Clue;
